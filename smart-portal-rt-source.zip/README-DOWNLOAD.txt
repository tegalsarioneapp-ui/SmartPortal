Smart Portal RT 005 Tegalsari - Source Code

Cara menjalankan di komputer lokal:
1. Install Node.js 20+ dan pnpm
2. Buka terminal di folder ini
3. Jalankan: pnpm install
4. Jalankan: pnpm --filter @workspace/smart-portal-rt run dev
5. Buka browser ke http://localhost:5173 (atau port yang tertera)

Atau cukup buka file artifacts/smart-portal-rt/index.html langsung
di browser modern (Chrome/Edge/Firefox) - aplikasi 100% client-side
menggunakan localStorage, tidak butuh server.
