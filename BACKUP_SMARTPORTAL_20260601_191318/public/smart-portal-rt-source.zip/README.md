# Smart Portal RT 005 Tegalsari — Source Code Lengkap
Generated: 2026-05-10 10:35 WIB

## Fitur Lengkap (Phase 6 Final)
1.  Multi-device realtime sync via PostgreSQL (SSE push + polling fallback)
2.  PWA installable (Android / iOS / Desktop) — manifest.json + service worker v2
3.  Web Push Notifications — admin kirim notif ke semua perangkat warga
4.  Warga aktifkan / nonaktifkan notifikasi push per perangkat (WebAuthn ready)
5.  Backup download langsung dari PostgreSQL (format JSON v2 + metadata)
6.  Restore batch ke server PostgreSQL — semua device diperbarui via SSE
7.  Export Excel: Data Warga, Kas RT, Iuran Bulanan (XLSX)
8.  Login biometrik (WebAuthn / sidik jari / Face ID) per warga
9.  Restore sesi terakhir otomatis (12 jam expire)
10. Scroll-to-top floating button
11. Offline banner merah saat tidak ada koneksi
12. Loading progress bar (3px gradient di atas)
13. Info Aplikasi card (total data DB, SSE subscribers, audit server)
14. Keyboard shortcut Ctrl+K untuk global search
15. Download PDF semua dokumen cetak (html2canvas + jsPDF)
16. Modul lengkap: Data KK, Kas RT, Iuran, Surat Pengantar, Arisan,
    Berita, Aduan Warga, Koperasi, Pengaturan Sistem

## Stack
- Frontend : Vite 7 + Vanilla JS + jQuery + SweetAlert2 + Select2
- Backend  : Express 5 + TypeScript + Zod + web-push (VAPID)
- Database : PostgreSQL via Drizzle ORM (Replit DB)
- Realtime : Server-Sent Events (SSE) + Web Push API

## Quick Start (Development)
```bash
pnpm install
pnpm --filter @workspace/db run push       # setup tabel PostgreSQL
# Terminal 1 — API server (port 8080):
PORT=8080 pnpm --filter @workspace/api-server run dev
# Terminal 2 — Frontend (port 5000):
PORT=5000 BASE_PATH=/ API_URL=http://localhost:8080 \
  pnpm --filter @workspace/smart-portal-rt run dev
```

## Production (satu proses Express)
```bash
pnpm run build
PORT=8080 NODE_ENV=production \
  node --enable-source-maps ./artifacts/api-server/dist/index.mjs
```

## API Endpoints
| Method | URL                          | Keterangan                    |
|--------|------------------------------|-------------------------------|
| GET    | /api/kv                      | Ambil semua key-value          |
| PUT    | /api/kv                      | Batch write key-value          |
| DELETE | /api/kv                      | Hapus key                     |
| GET    | /api/kv/stream               | SSE realtime stream            |
| GET    | /api/audit                   | Health check + statistik       |
| GET    | /api/push/vapid-public-key   | VAPID public key (frontend)    |
| GET    | /api/push/count              | Jumlah push subscriber         |
| POST   | /api/push/subscribe          | Daftarkan push subscription    |
| DELETE | /api/push/unsubscribe        | Hapus push subscription        |
| POST   | /api/push/send               | Kirim push ke semua subscriber |

## VAPID Keys (Production: ganti dengan keys baru)
Untuk generate keys baru:
```bash
node -e "require('web-push').generateVAPIDKeys()" 
```
Lalu set environment variables:
  VAPID_PUBLIC_KEY=<public>
  VAPID_PRIVATE=<private>
  VAPID_SUBJECT=mailto:admin@yourdomain.com

## Deployment URL
https://smartportal005.replit.app
