# Smart Portal RT 005 Tegalsari — Source Code
Generated: 2026-05-10 10:25

## Fitur Lengkap
- Multi-device realtime sync via PostgreSQL (SSE push + polling fallback)
- PWA installable (Android/iOS/Desktop) dengan manifest.json + service worker
- Backup/Restore langsung dari server PostgreSQL (bukan localStorage)
- Export Excel: Data Warga, Kas RT, Iuran Bulanan
- Export JSON backup + Restore batch ke server
- Portal Admin & Portal Warga dengan login biometrik (WebAuthn/sidik jari)
- Modul: Data KK, Kas RT, Iuran, Surat Pengantar, Arisan, Berita, Aduan, Koperasi, Pengaturan
- Offline banner, scroll-to-top, loading progress bar
- Info Aplikasi card (total data, SSE subscribers, audit server)
- Restore sesi terakhir (12 jam) + Keyboard shortcut Ctrl+K untuk search
- Download PDF semua dokumen cetak

## Stack
- Frontend: Vite 7 + Vanilla JS + jQuery + SweetAlert2 + Select2
- Backend: Express 5 + TypeScript + Zod
- Database: PostgreSQL via Drizzle ORM
- Realtime: Server-Sent Events (SSE)

## Development
```bash
pnpm install
pnpm --filter @workspace/db run push       # setup tabel PostgreSQL
# Terminal 1:
PORT=8080 pnpm --filter @workspace/api-server run dev
# Terminal 2:
PORT=5000 BASE_PATH=/ API_URL=http://localhost:8080 \
  pnpm --filter @workspace/smart-portal-rt run dev
```

## Production (satu proses)
```bash
pnpm run build
PORT=8080 NODE_ENV=production node --enable-source-maps ./artifacts/api-server/dist/index.mjs
```
Deployment URL: https://smartportal005.replit.app
